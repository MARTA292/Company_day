//const btnInscEmpr= document.querySelectorAll('#inscripcion_empresa');
function click_btnInscEmpr(){
    location.href = "company_day\templates\inscripcion_empresas.html";
}
//btnInscEmpr.addEventListener('click', location.href = "inscripcion_empresas.html");
