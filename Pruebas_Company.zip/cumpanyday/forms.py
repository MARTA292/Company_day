
class SignupForm():
    name = 'Nombre'
    password = 'Password'
    email = 'Email'
    submit = 'Registrar'